# 민원서비스 빠른 찾기

첨부 CSV의 22건 데이터를 기반으로 제작한 Vercel 배포용 정적 웹페이지입니다.

## 포함 기능
- 22건 서비스 목록 표시
- 서비스명 키워드 실시간 검색
- 민원분야 필터
- 검색 + 필터 동시 적용
- 현재 표시 건수 / 전체 건수 표시
- 반응형 PC·태블릿·모바일 UI
- 검색 결과 없음 안내
- 초기화 버튼

## Vercel 배포
1. 압축 해제 후 `index.html`을 GitHub 저장소의 최상위에 올립니다.
2. Vercel에서 **New Project → GitHub 저장소 선택 → Deploy**를 실행합니다.
3. 정적 HTML이므로 별도 Build Command/Output Directory가 필요하지 않습니다.
4. 배포 후 `https://프로젝트명.vercel.app` 주소가 생성됩니다.

## 폴더
- `index.html`: HTML/CSS/JS 및 CSV 데이터가 하나의 파일에 포함됨
- `README.md`: 배포 방법
